# real-time-transcribtion
Real time voice to text transcribtion with Faster Whisper

faster-whisper github: https://github.com/SYSTRAN/faster-whisper

1. pip install faster-whisper
2. pip install pyaudio, wave
3. set your whisper model in test2.py
4. parameters:
   beam_size=5 - adjust for accuracy (i think)
   chunk_lenght=1 - adjust for chunk size
5. run test2.py
